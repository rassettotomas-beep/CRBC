// ============================================
// CAMPEONATO DE BOCHAS
// COLONIA ROSA BOCHAS CLUB
// ============================================


// --------------------------------------------
// DATOS INICIALES
// --------------------------------------------

let campeonato = JSON.parse(
    localStorage.getItem("campeonatoBochas")
) || {

    equipos: [

        {
            id: 1,
            zona: "A",
            nombre: "Equipo 1",
            jugadores: ["", "", "", ""]
        },

        {
            id: 2,
            zona: "A",
            nombre: "Equipo 2",
            jugadores: ["", "", "", ""]
        },

        {
            id: 3,
            zona: "A",
            nombre: "Equipo 3",
            jugadores: ["", "", "", ""]
        },

        {
            id: 4,
            zona: "A",
            nombre: "Equipo 4",
            jugadores: ["", "", "", ""]
        },

        {
            id: 5,
            zona: "B",
            nombre: "Equipo 5",
            jugadores: ["", "", "", ""]
        },

        {
            id: 6,
            zona: "B",
            nombre: "Equipo 6",
            jugadores: ["", "", "", ""]
        },

        {
            id: 7,
            zona: "B",
            nombre: "Equipo 7",
            jugadores: ["", "", "", ""]
        },

        {
            id: 8,
            zona: "B",
            nombre: "Equipo 8",
            jugadores: ["", "", "", ""]
        },

        {
            id: 9,
            zona: "C",
            nombre: "Equipo 9",
            jugadores: ["", "", "", ""]
        },

        {
            id: 10,
            zona: "C",
            nombre: "Equipo 10",
            jugadores: ["", "", "", ""]
        },

        {
            id: 11,
            zona: "C",
            nombre: "Equipo 11",
            jugadores: ["", "", "", ""]
        },

        {
            id: 12,
            zona: "C",
            nombre: "Equipo 12",
            jugadores: ["", "", "", ""]
        }

    ],

    partidos: []

};


// --------------------------------------------
// GUARDAR DATOS
// --------------------------------------------

function guardarDatos() {

    localStorage.setItem(
        "campeonatoBochas",
        JSON.stringify(campeonato)
    );

    const estado = document.getElementById("estadoGuardado");

    if (estado) {

        estado.textContent =
            "💾 Datos guardados automáticamente";

        setTimeout(() => {

            estado.textContent =
                "💾 Datos guardados automáticamente";

        }, 1500);

    }

}


// --------------------------------------------
// CAMBIAR DE SECCIÓN
// --------------------------------------------

function mostrarSeccion(id) {

    document.querySelectorAll(".seccion")
        .forEach(seccion => {

            seccion.classList.remove("activa");

        });

    document.getElementById(id)
        .classList.add("activa");

}


// --------------------------------------------
// MOSTRAR EQUIPOS
// --------------------------------------------

function mostrarEquipos() {

    const contenedor =
        document.getElementById("listaEquipos");

    contenedor.innerHTML = "";


    ["A", "B", "C"].forEach(zona => {

        const titulo =
            document.createElement("h2");

        titulo.textContent =
            "Zona " + zona;

        contenedor.appendChild(titulo);


        campeonato.equipos
            .filter(equipo => equipo.zona === zona)
            .forEach(equipo => {

                const div =
                    document.createElement("div");

                div.className = "equipo";

                div.innerHTML = `

                    <h3>
                        ${equipo.nombre}
                    </h3>

                    <label>Nombre del equipo</label>

                    <input
                        value="${equipo.nombre}"
                        onchange="actualizarNombreEquipo(
                            ${equipo.id},
                            this.value
                        )"
                    >

                    <h4>Jugadores</h4>

                    <input
                        placeholder="Jugador titular 1"
                        value="${equipo.jugadores[0]}"
                        onchange="actualizarJugador(
                            ${equipo.id},
                            0,
                            this.value
                        )"
                    >

                    <input
                        placeholder="Jugador titular 2"
                        value="${equipo.jugadores[1]}"
                        onchange="actualizarJugador(
                            ${equipo.id},
                            1,
                            this.value
                        )"
                    >

                    <input
                        placeholder="Jugador titular 3"
                        value="${equipo.jugadores[2]}"
                        onchange="actualizarJugador(
                            ${equipo.id},
                            2,
                            this.value
                        )"
                    >

                    <input
                        placeholder="Jugador suplente"
                        value="${equipo.jugadores[3]}"
                        onchange="actualizarJugador(
                            ${equipo.id},
                            3,
                            this.value
                        )"
                    >

                `;

                contenedor.appendChild(div);

            });

    });

}


// --------------------------------------------
// ACTUALIZAR EQUIPO
// --------------------------------------------

function actualizarNombreEquipo(id, nombre) {

    const equipo =
        campeonato.equipos.find(e => e.id === id);

    if (!equipo) return;

    equipo.nombre = nombre;

    guardarDatos();

    mostrarZonas();

}


// --------------------------------------------
// ACTUALIZAR JUGADOR
// --------------------------------------------

function actualizarJugador(id, posicion, nombre) {

    const equipo =
        campeonato.equipos.find(e => e.id === id);

    if (!equipo) return;

    equipo.jugadores[posicion] = nombre;

    guardarDatos();

}


// --------------------------------------------
// GENERAR PARTIDOS
// --------------------------------------------

function generarPartidos(zona) {

    const equipos =
        campeonato.equipos.filter(
            equipo => equipo.zona === zona
        );

    const partidos = [];

    for (let i = 0; i < equipos.length; i++) {

        for (let j = i + 1; j < equipos.length; j++) {

            const existe =
                campeonato.partidos.find(
                    p =>
                        p.zona === zona &&
                        (
                            (
                                p.local === equipos[i].id &&
                                p.visitante === equipos[j].id
                            )
                            ||
                            (
                                p.local === equipos[j].id &&
                                p.visitante === equipos[i].id
                            )
                        )
                );


            if (existe) {

                partidos.push(existe);

            } else {

                const partido = {

                    id:
                        Date.now() +
                        Math.random(),

                    zona: zona,

                    local: equipos[i].id,

                    visitante: equipos[j].id,

                    puntosLocal: null,

                    puntosVisitante: null

                };

                campeonato.partidos.push(partido);

                partidos.push(partido);

            }

        }

    }

    guardarDatos();

    return partidos;

}


// --------------------------------------------
// MOSTRAR ZONAS
// --------------------------------------------

function mostrarZonas() {

    ["A", "B", "C"].forEach(zona => {

        const contenedor =
            document.getElementById(
                "contenidoZona" + zona
            );

        if (!contenedor) return;

        const partidos =
            generarPartidos(zona);


        let html = `
            <div class="tarjeta">

                <h3>Partidos - Zona ${zona}</h3>
        `;


        partidos.forEach(partido => {

            const local =
                campeonato.equipos.find(
                    e => e.id === partido.local
                );

            const visitante =
                campeonato.equipos.find(
                    e => e.id === partido.visitante
                );


            html += `

                <div class="partido">

                    <strong>
                        ${local.nombre}
                    </strong>

                    <input
                        type="number"
                        min="0"
                        max="15"
                        value="${
                            partido.puntosLocal ?? ""
                        }"
                        onchange="
                            actualizarResultado(
                                ${partido.id},
                                'local',
                                this.value
                            )
                        "
                    >

                    <span> - </span>

                    <input
                        type="number"
                        min="0"
                        max="15"
                        value="${
                            partido.puntosVisitante ?? ""
                        }"
                        onchange="
                            actualizarResultado(
                                ${partido.id},
                                'visitante',
                                this.value
                            )
                        "
                    >

                    <strong>
                        ${visitante.nombre}
                    </strong>

                </div>

            `;

        });


        html += `

            </div>

            <div class="tarjeta">

                <h3>
                    📊 Tabla de posiciones
                </h3>

                ${generarTabla(zona)}

            </div>

        `;


        contenedor.innerHTML = html;

    });

}


// --------------------------------------------
// ACTUALIZAR RESULTADO
// --------------------------------------------

function actualizarResultado(
    id,
    equipo,
    valor
) {

    const partido =
        campeonato.partidos.find(
            p => p.id == id
        );

    if (!partido) return;


    let puntos =
        valor === ""
            ? null
            : Number(valor);


    if (
        puntos !== null &&
        (puntos < 0 || puntos > 15)
    ) {

        alert(
            "Los partidos son a 15 puntos."
        );

        mostrarZonas();

        return;

    }


    if (equipo === "local") {

        partido.puntosLocal = puntos;

    } else {

        partido.puntosVisitante = puntos;

    }


    guardarDatos();

    mostrarZonas();

}


// --------------------------------------------
// TABLA DE POSICIONES
// --------------------------------------------

function generarTabla(zona) {

    const equipos =
        campeonato.equipos.filter(
            e => e.zona === zona
        );


    const tabla =
        equipos.map(equipo => ({

            equipo: equipo,

            PJ: 0,

            PG: 0,

            PP: 0,

            puntos: 0

        }));


    campeonato.partidos
        .filter(p => p.zona === zona)
        .forEach(partido => {

            if (
                partido.puntosLocal === null ||
                partido.puntosVisitante === null
            ) return;


            if (
                partido.puntosLocal ===
                partido.puntosVisitante
            ) return;


            const local =
                tabla.find(
                    t =>
                        t.equipo.id ===
                        partido.local
                );


            const visitante =
                tabla.find(
                    t =>
                        t.equipo.id ===
                        partido.visitante
                );


            local.PJ++;

            visitante.PJ++;


            if (
                partido.puntosLocal >
                partido.puntosVisitante
            ) {

                local.PG++;

                visitante.PP++;

                local.puntos++;

            } else {

                visitante.PG++;

                local.PP++;

                visitante.puntos++;

            }

        });


    tabla.sort(
        (a, b) =>
            b.puntos - a.puntos
    );


    let html = `

        <table>

            <thead>

                <tr>

                    <th>Pos.</th>
                    <th>Equipo</th>
                    <th>PJ</th>
                    <th>PG</th>
                    <th>PP</th>
                    <th>Puntos</th>

                </tr>

            </thead>

            <tbody>

    `;


    tabla.forEach((fila, indice) => {

        html += `

            <tr>

                <td>
                    ${indice + 1}
                </td>

                <td>
                    ${fila.equipo.nombre}
                </td>

                <td>
                    ${fila.PJ}
                </td>

                <td>
                    ${fila.PG}
                </td>

                <td>
                    ${fila.PP}
                </td>

                <td>
                    <strong>
                        ${fila.puntos}
                    </strong>
                </td>

            </tr>

        `;

    });


    html += `

            </tbody>

        </table>

    `;


    return html;

}


// --------------------------------------------
// INICIAR APLICACIÓN
// --------------------------------------------

document.addEventListener(
    "DOMContentLoaded",
    () => {

        mostrarEquipos();

        mostrarZonas();

    }
);